class ModelType:
    NONE = 0
    LOCALIZATION = 1
    CLASSIFICATION = 2